import './App.css';
import MarketTable from './components/MarketTable';

function App() {
  return (
    <div className="App">
      <MarketTable />
    </div>
  );
}

export default App;
